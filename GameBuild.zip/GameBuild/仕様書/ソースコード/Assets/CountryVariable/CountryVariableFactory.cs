using UnityEngine;

public static class CountryVariableFactory
{
    public static void CreatePostVariable(UnlockTagKey unlockKey)
    {
        // post�t���L�[����
        var postKey = new UnlockTagKey
        {
            tag = unlockKey.tag,
            key = unlockKey.key + "_post"
        };

        // ���ɑ��݂���Ȃ���Ȃ�
        var existing =
            CountryVariableManager.Instance.GetByKey(postKey);

        if (existing != null)
            return;

        // CountryVariable����
        CountryVariable variable = new CountryVariable();

        variable.tag = postKey.tag;
        variable.key = postKey.key;

        // �����l�i�K�v�Ȃ璲���j
        variable.yes = 0;
        variable.no = 0;
        variable.neutral = 100;

        variable.debatePoint = 0;
        variable.debateLevel = 1;

        // �o�^
        CountryVariableManager.Instance.Register(variable);

        Debug.Log($"CountryVariable created : {postKey.tag} / {postKey.key}");
    }
}