using UnityEngine;

public static class LargeScaleDebatePointRule
{
    public static int ClampDebatePoint(int currentValue)
    {
        if (CountryConstantManager.Instance == null)
            return currentValue;

        // ���܂͐l���x�[�X�i�����g���j
        int max = CountryConstantManager.Instance.GetLargeScaleMaxDebatePoint();
        return Mathf.Min(currentValue, max);
    }
}
