using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System;

// �f�[�^�Ǘ��AOption��ێ��ACurrent��؂�ւ��邾���@UI��G��Ȃ��B
[DefaultExecutionOrder(-100)]
public class CountryVariableManager : MonoBehaviour
{
    public static CountryVariableManager Instance { get; private set; }

    private Dictionary<UnlockTagKey, CountryVariable> variablesByKey = new();
    private Dictionary<UnlockTag, CountryVariable> variablesByTag = new();

    // UI ���Q�Ƃ��� Current
    private CountryVariable current;
    public CountryVariable Current => current;

    public event Action<DebateTag> OnDebateVariableUpdated;

    public event Action<UnlockTagKey> OnVariableUpdated;




    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

    }

    public void Register(CountryVariable variable)
    {
        var key = variable.TagKey;

        variablesByKey[key] = variable;

        if (string.IsNullOrEmpty(variable.key))
            variablesByTag[variable.tag] = variable;
    }
  


    public CountryVariable GetByKey(UnlockTagKey key)
    {
        // �@ ���S��v�iTag+Key�j
        if (variablesByKey.TryGetValue(key, out var v))
            return v;

        // �A �t�H�[���o�b�N�iTag�̂݁j
        if (variablesByTag.TryGetValue(key.tag, out v))
            return v;

        return null;
    }

    
    


    /// <summary>
    /// ���ׂĂ� Variable ���擾�i�g���p�j
    /// </summary>
    public IReadOnlyCollection<CountryVariable> GetAll()
    {
       return variablesByTag.Values;
    }

   //�ȉ��̈����͕ۗ��ŏI�I�ɏ��������i�Q�O�Q�U�N�R���S���P�V���j

    public void ApplyPost(UnlockTagKey tagKey, CountryVariable.PostChoice choice, int mainAdd,
    int subAdd,
    int neutralAdd)
    {
        var variable = GetByKey(tagKey);
        if (variable == null)
            return;

        int max =
        CountryConstantManager.Instance
            .GetCapValue(variable.capSource);

        variable.ApplyPostAdvanced(choice, mainAdd, subAdd, neutralAdd, max);

        
        variable.UpdateDebateLevel();

        OnVariableUpdated?.Invoke(tagKey);

        // Debate�n�������C�x���g���ʒm
        if (tagKey.key == "")
        {
            OnDebateVariableUpdated?.Invoke((DebateTag)tagKey.tag);
        }
    }
    public CountryVariable GetByTag(UnlockTag tag)
    {
        return GetByKey(new UnlockTagKey { tag = tag, key = "" });
    }

}