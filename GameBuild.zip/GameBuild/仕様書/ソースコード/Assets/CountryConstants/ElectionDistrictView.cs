using UnityEngine;
using TMPro;

public class ElectionDistrictView : MonoBehaviour
{
    public TMP_Text leadernameText;
    public TMP_Text totalPopText;
    public TMP_Text partyText;
    
    
    public void Setup(ElectionDistrictData data)
    {
  
     if (data == null) return;

        // ���[�_�[��
        if (data.leader != null)
            leadernameText.text = data.leader.name;
        else
            leadernameText.text = "�Ȃ�";

        // ���}
        if (data.leader != null && data.leader.party != null)
            partyText.text = data.leader.party.partyName;
        else
            partyText.text = "������";

        // ���l���i��Œǉ����� totalPopulation�j
        totalPopText.text = $" {data.totalPopulation} �l";
    }

    
}
