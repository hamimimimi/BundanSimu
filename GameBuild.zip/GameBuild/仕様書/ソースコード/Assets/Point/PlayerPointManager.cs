using UnityEngine;

public class PlayerPointManager : MonoBehaviour
{
    public static PlayerPointManager Instance { get; private set; }

    [SerializeField]
    int currentPoint = 0;

    // UnlockButton ���Q�Ƃ���p
    public int CurrentPoint => currentPoint;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    // ���͏�ɑ���Ă��邱�Ƃɂ���i�������j
    public bool HasEnough(int cost)
    {
        return currentPoint >= cost;
    }

    // UnlockButton ����Ă΂��
    public bool Consume(int cost)
    {
        if (currentPoint < cost)
            return false;

        currentPoint -= cost;
        return true;
    }

    // TurnEnd �Ȃǂ���Ăԗ\��
    public void AddPoint(int value)
    {
        currentPoint += value;
    }
}
