using System.Collections.Generic;
using UnityEngine;

public class UnlockProgressManager : MonoBehaviour
{
    public static UnlockProgressManager Instance;

    private Dictionary<UnlockTagKey, float> progress = new();

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    public float GetProgress(UnlockTagKey key)
    {
        progress.TryGetValue(key, out float value);
        return value;
    }

    public void AddProgress(UnlockTagKey key, float amount)
    {
        if (!progress.ContainsKey(key))
            progress[key] = 0f;

        progress[key] += amount;
    }

    public bool IsComplete(UnlockTagKey key, float required)
    {
        return GetProgress(key) >= required;
    }

    // �݊��p�i�����R�[�h���c���Ă���Ԃ����j��ŏ���
    public bool IsComplete(UnlockTag tag, string key, float required)
    {
        return IsComplete(new UnlockTagKey { tag = tag, key = key }, required);
    }
}
