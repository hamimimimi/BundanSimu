using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MyAccListUI : MonoBehaviour
{
    public GameObject MyAccitemPrefab;  // CharacterItem prefab
    public Transform Content;      // ListPanel �� Content

    public void RefreshList()
    {
        // �Â��ꗗ���폜
        foreach (Transform child in Content)
        {
            Destroy(child.gameObject);
        }

        // �V�����ꗗ�\��
        foreach (var c in MyAccManager.Instance.MyAccs)
        {
            GameObject obj = Instantiate(MyAccitemPrefab, Content);
            obj.GetComponentInChildren<TMP_Text>().text = $"{c.name}";
        }
    }
}
