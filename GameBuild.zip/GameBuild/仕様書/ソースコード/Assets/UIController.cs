using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.Serialization;
using UnityEngine.UIElements;

public class UIController : MonoBehaviour
{
    public Transform contentParent;   // ScrollView -> Viewport -> Content ���Z�b�g
    public GameObject itemPrefab;     // Project ���� prefab ���Z�b�g
    public ScrollRect scrollRect;     // ScrollRect ���Z�b�g�i�g�b�v�ɖ߂����߁j
    


    public void RefreshListUI()
    {
        Debug.Log("RefreshListUI START. contentParent=" + (contentParent ? contentParent.name : "NULL"));

        if (contentParent == null || itemPrefab == null)
        {
            Debug.LogError("UIController: contentParent or itemPrefab is null!");
            return;
        }

        // �����̎q��S�������iRuntime�j
        for (int i = contentParent.childCount - 1; i >= 0; i--)
        {
            Destroy(contentParent.GetChild(i).gameObject);
        }

        // �ǂݍ���
        List<MyAccData> list = SaveMyAccSystem.LoadAll();
        Debug.Log("Loaded list count: " + (list != null ? list.Count.ToString() : "null"));

        if (list == null || list.Count == 0)
        {
           

            // ���C�A�E�g�X�V���ăX�N���[���g�b�v
            Canvas.ForceUpdateCanvases();
            if (scrollRect != null) scrollRect.verticalNormalizedPosition = 1f;
            return;
        }

        foreach (var data in list)
        {
            // Instantiate(prefab, parent, false) ���g���ƃ��[�J�� transform ���������Ȃ�
            GameObject go = Instantiate(itemPrefab, contentParent, false);

            // �������Z�b�g�i�ی��j
            RectTransform rt = go.GetComponent<RectTransform>();
            if (rt != null)
            {
                rt.localRotation = Quaternion.identity;
                rt.localScale = Vector3.one;
                rt.anchorMin = new Vector2(0f, 1f);
                rt.anchorMax = new Vector2(1f, 1f);
                rt.pivot = new Vector2(0.5f, 1f);
                rt.anchoredPosition = Vector2.zero;
            }

            // Setup�iMyAccItem�����݂���΁j
            var item = go.GetComponent<MyAccItem>();
            if (item != null)
            {
                item.Setup(data, id => OnDeleteRequested(id));
            }
            else
            {
                Debug.LogWarning("Instantiated prefab has no MyAccItem component: " + go.name);
            }
        }

        // ���C�A�E�g�č\�z�i�m���ɔ��f������j
        Canvas.ForceUpdateCanvases();
        // �������C�A�E�g�č\�z�iContent �� RectTransform�j
        var contentRect = contentParent as RectTransform;
        if (contentRect != null)
            UnityEngine.UI.LayoutRebuilder.ForceRebuildLayoutImmediate(contentRect);

        // �X�N���[�������
        if (scrollRect != null) scrollRect.verticalNormalizedPosition = 1f;

        Debug.Log("RefreshListUI END");

       

    }

    


    public void OnDeleteRequested(string id)
    {
        var list = SaveMyAccSystem.LoadAll();
        list.RemoveAll(x => x.id == id);
        SaveMyAccSystem.SaveAll(list);
        RefreshListUI();
    }
}