using UnityEngine;

// CountryVariable�p�̕\��Tag
public enum DebateTag
{
    None,       // �e���Ȃ�
    OptionA,
    OptionB,
    OptionC,
    OptionD,
}

// LargeScaleData�p�̕\��Tag
public enum LargeScaleType
{
    Economy,
    Military,
    Environment
}

// ���ׂĂ�UnlockButton�ŊJ��������̂�Tag
public enum UnlockTag
{
    None,

    // Variable ���
    DebateEconomy,
    DebateMilitary,
    DebateEnvironment,

    // Constant ���
    PopulationInfo,
    GovernmentInfo,
    Landinfo,

    // �@�\���
    PolicySystem,
    ElectionSystem,

    ForeignCountryInfo,
PoliticalPartyInfo,
    PoliticalParty,
    Issue,
    ForeignCountry,
    Politician,
    District,
    DistrictIssue,
    ElectionIssue,
    Election
}




