using UnityEngine;
using System;
using System.Collections.Generic;

public class TagManager : MonoBehaviour
{
    public static TagManager Instance { get; private set; }
  

    // Tag + Key ����i���}�E�֌W���ȂǁjTag �P�̉����Key���h�h
    private Dictionary<UnlockTag, HashSet<string>> unlockedKeys = new();

    public event Action OnUnlockStateChanged;


    private void Awake()
    {
       
        if (Instance != null)
        {
           
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public void Unlock(UnlockTag tag, string key = "")
    {
        Debug.Log($"UNLOCK: {tag} / {key}");

        if(!unlockedKeys.TryGetValue(tag, out var set))
        {
            set = new HashSet<string>();
            unlockedKeys[tag] = set;
        }
        if (set.Add(key))
            OnUnlockStateChanged?.Invoke();

    }
   
    public bool IsUnlocked(UnlockTag tag)
      => IsUnlocked(new UnlockTagKey { tag = tag, key = "" });

    public bool IsUnlocked(UnlockTagKey key)
    {
        // �@ ���S��v
        if (unlockedKeys.TryGetValue(key.tag, out var set)
            && set.Contains(key.key))
            return true;

        // �A Tag�̂݉������Ă���� true
        if (key.key != ""
            && unlockedKeys.TryGetValue(key.tag, out set)
            && set.Contains(""))
            return true;

        return false;
    }

    public List<UnlockTagKey> GetUnlockedTagKeys()
    {
        var list = new List<UnlockTagKey>();

        foreach (var pair in unlockedKeys)
        {
            foreach (var key in pair.Value)
            {
                list.Add(new UnlockTagKey
                {
                    tag = pair.Key,
                    key = key
                });
            }
        }
        return list;
    }
}
